---
layout: default
title: Home
---

# 🐧 Linux MMORPG Scripts 🎮

Welcome!  
This site collects **bash scripts** and guides for running MMORPGs on Linux.  
All scripts are tested manually.

## Featured Games
- [Lineage 2 Reborn]({% post_url 2025-09-29-lineage2 %})
- [Ragnarok Online (uaRO)]({% post_url 2025-09-29-ragnarok-online %})

---

⚠️ Disclaimer: These scripts are for educational purposes only.  
We are not affiliated with any game publisher. Use at your own risk.
